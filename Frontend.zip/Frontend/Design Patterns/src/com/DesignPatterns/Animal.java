package com.DesignPatterns;

 class Animal {
     void eat(){
         System.out.println("eating");
     }
  class Dog extends Animal{ //single
         void bark(){
             System.out.println("barking");
         }
  }
  class Cat extends Dog{ //multi-level
         void drink(){
             System.out.println("drinking");
         }
  }
     class Cat1 extends Animal{ //hierarchial
         void drink(){
             System.out.println("Drinking and sleeping");
         }
}
  public static void main(String[] args){
         Animal a=new Animal();
         a.eat();
         Animal.Dog d=a.new Dog();
         d.bark();
         Animal.Cat c=a.new Cat();
         c.drink();
         Animal.Cat1 c1=a.new Cat1();
         c1.drink();

  }
}
