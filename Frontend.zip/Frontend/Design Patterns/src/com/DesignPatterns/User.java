package com.DesignPatterns;

public class User {
   private String name;
   private int age;

   public void setDetails(String name,int age){   //encapsulation
       this.name=name;
       this.age=age;
   }
   public String getName(){
       return name;
   }
   public int getAge(){
       return age;
   }
}
