package com.DesignPatterns;


public class Main {
    public static void main(String args[]){
        User user=new User();
        SendMail sendmail=new SendMail();

        sendmail.sendMail();

        user.setDetails("shannu",29);
        System.out.println(user.getName()+","+user.getAge());
    }
}
  