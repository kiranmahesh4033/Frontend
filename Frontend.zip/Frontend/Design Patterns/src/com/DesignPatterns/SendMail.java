package com.DesignPatterns;

public class SendMail {

    public void sendMail(){
        connect();
        authenticate();
        disconnect();
    }

    private void connect(){
        System.out.println("Connected");
    }
    private void disconnect(){
        System.out.println("Disconnected");
    }
    private void authenticate(){
        System.out.println("Authenticated");
    }
}
