public class Singleton {
    private static Singleton instance = null;
    public String s;

    private Singleton() {
        s = "String from Singleton class";
    }

    public static Singleton getInstance() {
        if (instance == null) {
            instance = new Singleton();
        }
        return instance;
    }

    public static void main(String[] args) {
        Singleton x = Singleton.getInstance();
        Singleton y = Singleton.getInstance();

        x.s = x.s.toUpperCase();
        System.out.println("String from x: " + x.s + ", y: " + y.s);

        y.s = y.s.toLowerCase();
        System.out.println("String from x: " + x.s + ", y: " + y.s);
    }
}
