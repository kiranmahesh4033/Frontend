// First interface
interface Walkable {
    void walk();
}

// Second interface
interface Playable {
    void play();
}

// A class implementing both interfaces — Multiple Inheritance via interfaces
class Child implements Walkable, Playable {
    public void walk() {
        System.out.println("Child is walking");
    }

    public void play() {
        System.out.println("Child is playing");
    }
}

class MultipleInheritanceDemo {
    public static void main(String[] args) {
        Child c = new Child();
        c.walk();  // from Walkable
        c.play();  // from Playable
    }
}
