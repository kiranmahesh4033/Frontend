

// Single Inheritance: Animal → Dog
class Animal {
    void eat() {
        System.out.println("Animal is eating");
    }
}

// Dog extends Animal → Single Inheritance
class Dog extends Animal {
    void bark() {
        System.out.println("Dog is barking");
    }
}

// Cat also extends Animal → Hierarchical Inheritance
class Cat extends Animal{
    void meow() {
        System.out.println("Cat is meowing");
    }
}

// Puppy extends Dog → Multilevel Inheritance
class Puppy extends Dog {
    void weep() {
        System.out.println("Puppy is weeping");
    }
}

public class InheritanceImplementation{
    public static void main(String[] args) {
        // Single Inheritance Example
        Dog dog = new Dog();
        dog.eat();   // from Animal
        dog.bark();  // from Dog

        // Hierarchical Inheritance Example
        Cat cat = new Cat();
        cat.eat();   // from Animal
        cat.meow();  // from Cat

        // Multilevel Inheritance Example
        Puppy puppy = new Puppy();
        puppy.eat();   // from Animal
        puppy.bark();  // from Dog
        puppy.weep();  // from Puppy
    }
}
