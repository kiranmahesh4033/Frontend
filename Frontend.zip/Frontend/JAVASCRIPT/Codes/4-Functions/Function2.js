function add(a, b) {
    return a + b;
}
//calling functions
console.log(add(3,4));
console.log(add(2,9));