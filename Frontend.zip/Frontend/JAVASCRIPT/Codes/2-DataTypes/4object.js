const details = {
	name:"Venkatesh", 
	designation:"Trainer", 
	location:"Chennai"
	};
console.log(details);