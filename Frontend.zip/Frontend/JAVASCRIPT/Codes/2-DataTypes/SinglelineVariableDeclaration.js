let name = 'Venkatesh', designation = "Trainer";
console.log(name+" " +designation);