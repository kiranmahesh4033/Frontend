let dailyActivities = ['eat', 'sleep'];

dailyActivities[2] = 'exercise';  //Add the new element at the 2 index

console.log(dailyActivities);     //['eat', 'sleep', 'exercise']